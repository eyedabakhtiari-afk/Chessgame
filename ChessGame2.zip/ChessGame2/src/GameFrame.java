import javax.swing.*;
import java.awt.*;

public class GameFrame extends JFrame {

    public GameFrame() {
        setTitle("Chess Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        CapturedPiecesPanel capturedPanel = new CapturedPiecesPanel();
        TimerPanel timerPanel = new TimerPanel();
        BoardPanel boardPanel = new BoardPanel(capturedPanel, timerPanel);

        add(boardPanel, BorderLayout.CENTER);
        add(capturedPanel, BorderLayout.EAST);
        add(timerPanel, BorderLayout.SOUTH);

        pack();
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
