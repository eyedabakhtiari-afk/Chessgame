import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;

public class TimerPanel extends JPanel {

    private JLabel whiteLabel;
    private JLabel blackLabel;

    private Timer timer;

    // زمان اولیه هر بازیکن (مثلاً 10 دقیقه)
    private int whiteSeconds = 600;
    private int blackSeconds = 600;

    private boolean whiteTurn = true;

    private DecimalFormat df = new DecimalFormat("00");

    public TimerPanel() {

        setLayout(new GridLayout(1, 2));

        whiteLabel = new JLabel("White: 10:00", SwingConstants.CENTER);
        blackLabel = new JLabel("Black: 10:00", SwingConstants.CENTER);

        whiteLabel.setFont(new Font("Serif", Font.BOLD, 18));
        blackLabel.setFont(new Font("Serif", Font.BOLD, 18));

        add(whiteLabel);
        add(blackLabel);

        // هر 1 ثانیه
        timer = new Timer(1000, e -> tick());

        timer.start();
    }

    private void tick() {

        if (whiteTurn) {

            if (whiteSeconds > 0) {
                whiteSeconds--;
            }

        } else {

            if (blackSeconds > 0) {
                blackSeconds--;
            }
        }

        updateLabels();

        checkGameOver();
    }

    private void updateLabels() {

        whiteLabel.setText("White: " + formatTime(whiteSeconds));
        blackLabel.setText("Black: " + formatTime(blackSeconds));
    }

    private String formatTime(int totalSeconds) {

        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;

        return df.format(minutes) + ":" + df.format(seconds);
    }

    private void checkGameOver() {

        if (whiteSeconds == 0) {

            timer.stop();

            JOptionPane.showMessageDialog(
                    this,
                    "White ran out of time!\nBlack wins!"
            );

        } else if (blackSeconds == 0) {

            timer.stop();

            JOptionPane.showMessageDialog(
                    this,
                    "Black ran out of time!\nWhite wins!"
            );
        }
    }

    public void setWhiteTurn(boolean whiteTurn) {
        this.whiteTurn = whiteTurn;
    }
}