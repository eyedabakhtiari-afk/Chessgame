import javax.swing.*;
import java.awt.*;
import pieces.Piece;

public class CapturedPiecesPanel extends JPanel {

    private JTextArea whiteCapturedArea;
    private JTextArea blackCapturedArea;

    public CapturedPiecesPanel() {

        setLayout(new GridLayout(2, 1));

        whiteCapturedArea = new JTextArea();
        blackCapturedArea = new JTextArea();

        whiteCapturedArea.setEditable(false);
        blackCapturedArea.setEditable(false);

        // مهم
        whiteCapturedArea.setLineWrap(true);
        blackCapturedArea.setLineWrap(true);

        // فونت درست
        Font chessFont = new Font("Dialog", Font.PLAIN, 28);

        whiteCapturedArea.setFont(chessFont);
        blackCapturedArea.setFont(chessFont);

        whiteCapturedArea.setBorder(
                BorderFactory.createTitledBorder("Captured White Pieces"));

        blackCapturedArea.setBorder(
                BorderFactory.createTitledBorder("Captured Black Pieces"));

        add(new JScrollPane(whiteCapturedArea));
        add(new JScrollPane(blackCapturedArea));
    }

    public void addCapturedPiece(Piece piece) {

        String symbol = piece.getSymbol();

        if (piece.isWhite()) {
            whiteCapturedArea.append(symbol + " ");
        } else {
            blackCapturedArea.append(symbol + " ");
        }

        repaint();
        revalidate();
    }
}
