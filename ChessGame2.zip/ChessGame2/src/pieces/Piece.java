package pieces;

import java.util.ArrayList;
import java.util.List;

public abstract class Piece {
    protected boolean white;
    protected String symbol;

    public Piece(boolean white, String symbol) {
        this.white = white;
        this.symbol = symbol;
    }

    public boolean isWhite() {
        return white;
    }

    public String getSymbol() {
        return symbol;
    }

    public abstract boolean isValidMove(int sr, int sc, int dr, int dc, Piece[][] board);

    public List<int[]> getValidMoves(int row, int col, Piece[][] board) {
        List<int[]> validMoves = new ArrayList<>();

        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                if (isValidMove(row, col, r, c, board)) {
                    validMoves.add(new int[]{r, c});
                }
            }
        }

        return validMoves;
    }
}
