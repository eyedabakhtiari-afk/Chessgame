package pieces;

public class King extends Piece {

    public King(boolean white) {
        super(white, white ? "♔" : "♚");
    }

    private boolean hasMoved = false;
    public boolean hasMoved(){ return hasMoved; }

    public void setMoved (boolean moved){
        this.hasMoved = moved;
    }

    @Override
    public boolean isValidMove(int sr, int sc, int dr, int dc, Piece[][] board) {

         // عدم حرکت
        if (sr == dr && sc == dc) return false;

        int r = Math.abs(sr - dr);
        int c = Math.abs(sc - dc);

        // شاه در تمام جهات فقط میتواند 1 خانه حرکت کند
        if (r <= 1 && c <= 1) {
        return board[dr][dc] == null || board[dr][dc].isWhite() != this.isWhite();
    }


        // --- منطق حرکت ساختاری قلعه ---
        // شاه نباید قبلاً حرکت کرده باشد و نباید تغییر ردیف داشته باشیم و جابه‌جایی ستون باید دقیقاً ۲ خانه باشد
        if (!hasMoved && sr == dr && c == 2) {
            int expectedRow = this.isWhite() ? 7 : 0;
            if (sr != expectedRow) return false;

            // قلعه کوچک (سمت راست - ستون 6)
            if (dc == 6) {
                if (board[sr][5] != null || board[sr][6] != null) return false;

                Piece rook = board[sr][7];
                return rook instanceof Rook && !((Rook) rook).hasMoved();
            }

            // قلعه بزرگ (سمت چپ - ستون 2)
            if (dc == 2) {
                if (board[sr][1] != null || board[sr][2] != null) return false;

                Piece rook = board[sr][0];
                return rook instanceof Rook && !((Rook) rook).hasMoved();
            }
        }
        
        return false;
    }
}

