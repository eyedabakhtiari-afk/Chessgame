package pieces;

public class Rook extends Piece {

    public Rook(boolean white) {
        super(white, white ? "♖" : "♜");
    }

    private boolean hasMoved = false;
    public boolean hasMoved(){ return hasMoved; }

    public void setMoved (boolean moved){
        this.hasMoved = moved;
    }

    @Override
    public boolean isValidMove(int sr, int sc, int dr, int dc, Piece[][] board) {
        // داخل صفحه
        if (dr < 0 || dr >= 8 || dc < 0 || dc >= 8) return false;

        // عدم حرکت
        if (sr == dr && sc == dc) return false;

        // باید یا افقی یا عمودی باشد
        if (sr != dr && sc != dc) return false;

        // مقصد هم‌رنگ نباشد
        Piece from = board[sr][sc];
        Piece to = board[dr][dc];
        if (to != null && from != null && to.isWhite() == from.isWhite()) return false;

        // مسیر خالی باشد (به جز مقصد)
        int rowStep = Integer.compare(dr - sr, 0); // -1,0,+1
        int colStep = Integer.compare(dc - sc, 0);

        int r = sr + rowStep;
        int c = sc + colStep;

        while (r != dr || c != dc) {
            if (board[r][c] != null) return false;
            r += rowStep;
            c += colStep;
        }

        return true;
    }
}
