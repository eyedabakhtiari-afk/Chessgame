package pieces;

public class Bishop extends Piece {

    public Bishop(boolean white) {
        super(white, white ? "♗" : "♝");
    }

    @Override
    public boolean isValidMove(int sr, int sc, int dr, int dc, Piece[][] board) {
        // داخل صفحه
        if (dr < 0 || dr >= 8 || dc < 0 || dc >= 8) return false;

        // عدم حرکت
        if (sr == dr && sc == dc) return false;

        // حرکت قطری
        if (Math.abs(sr - dr) != Math.abs(sc - dc)) return false;

        // مقصد هم‌رنگ نباشد
        Piece from = board[sr][sc];
        Piece to = board[dr][dc];
        if (to != null && from != null && to.isWhite() == from.isWhite()) return false;

        // مسیر باید خالی باشد (به جز خود مقصد)
        int rowStep = (dr > sr) ? 1 : -1;
        int colStep = (dc > sc) ? 1 : -1;

        int r = sr + rowStep;
        int c = sc + colStep;

        while (r != dr && c != dc) {
            if (board[r][c] != null) return false;
            r += rowStep;
            c += colStep;
        }

        return true;
    }
}
