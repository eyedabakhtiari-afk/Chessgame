package pieces;

public class Knight extends Piece {

    public Knight(boolean white) {
        super(white, white ? "♘" : "♞");
    }

    @Override
    public boolean isValidMove(int sr, int sc, int dr, int dc, Piece[][] board) {

         // عدم حرکت
        if (sr == dr && sc == dc) return false;

        int r = Math.abs(sr - dr);
        int c = Math.abs(sc - dc);

        boolean isKnightPattern = (r == 2 && c == 1) || (r == 1 && c == 2);

        if (!isKnightPattern) return false;

        return board[dr][dc] == null || board[dr][dc].isWhite() != this.isWhite();
    }
}
