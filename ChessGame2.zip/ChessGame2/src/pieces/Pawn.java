package pieces;

public class Pawn extends Piece {

    public Pawn(boolean white) {
        super(white, white ? "♙" : "♟");
    }

    @Override
    public boolean isValidMove(int sr, int sc, int dr, int dc, Piece[][] board) {

        int direction = white ? -1 : 1;

        if (sc == dc && board[dr][dc] == null) {
            if (dr == sr + direction) return true;

            if (white && sr == 6 && dr == 4){
                if (board[4][sc] == null && board[5][sc] ==null) {
                    return true; }}
            if (!white && sr == 1 && dr == 3)  
                if (board[3][sc] == null && board[2][sc] ==null) {
                    return true; }}
    

        if (Math.abs(dc - sc) == 1 && dr == sr + direction) {
            if (board[dr][dc] != null && board[dr][dc].isWhite() != this.isWhite()) {
            return true;
            }
        }
        return false;
    }
}
