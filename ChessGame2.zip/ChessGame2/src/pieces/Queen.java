package pieces;

public class Queen extends Piece {

    public Queen(boolean white) {
        super(white, white ? "♕" : "♛");
    }

    @Override
    public boolean isValidMove(int sr, int sc, int dr, int dc, Piece[][] board) {

        // مقصد داخل صفحه باشد
        if (dr < 0 || dr >= 8 || dc < 0 || dc >= 8) return false;

        // درجا نماند
        if (sr == dr && sc == dc) return false;

        // مقصد هم‌رنگ نباشد
        Piece target = board[dr][dc];
        if (target != null && target.isWhite() == this.isWhite()) return false;

        // حرکت عمودی
        if (sc == dc) {
            int step = (dr > sr) ? 1 : -1;
            for (int r = sr + step; r != dr; r += step) {
                if (board[r][sc] != null) return false;
            }
            return true;
        }

        // حرکت افقی
        if (sr == dr) {
            int step = (dc > sc) ? 1 : -1;
            for (int c = sc + step; c != dc; c += step) {
                if (board[sr][c] != null) return false;
            }
            return true;
        }

        // حرکت مورب
        if (Math.abs(sr - dr) == Math.abs(sc - dc)) {
            int rowStep = (dr > sr) ? 1 : -1;
            int colStep = (dc > sc) ? 1 : -1;

            int r = sr + rowStep;
            int c = sc + colStep;

            while (r != dr || c != dc) {
                if (board[r][c] != null) return false;
                r += rowStep;
                c += colStep;
            }

            return true;
        }

        return false;
    }
}
