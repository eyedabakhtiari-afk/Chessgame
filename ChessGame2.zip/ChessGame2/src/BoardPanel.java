import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.ArrayList;

import pieces.*;

public class BoardPanel extends JPanel {

    private CapturedPiecesPanel capturedPanel;
    private TimerPanel timerPanel;
    private JButton[][] squares = new JButton[8][8];
    private Board board;

    private int selectedRow = -1;
    private int selectedCol = -1;
    private List<int[]> currentHighlights = new ArrayList<>();

    private boolean whiteTurn = true;

    private static final Color LIGHT_SQUARE = new Color(240, 217, 181);
    private static final Color DARK_SQUARE = new Color(181, 136, 99);
    private static final Color SELECTED_COLOR = Color.YELLOW;
    private static final Color HIGHLIGHT_COLOR = new Color(144, 238, 144);

    public BoardPanel(CapturedPiecesPanel capturedPanel, TimerPanel timerPanel) {
        this.capturedPanel = capturedPanel;
        this.timerPanel = timerPanel;
        this.board = new Board();

        setLayout(new GridLayout(8, 8));
        drawBoard();
        refreshBoard();
        resetColors();
    }

    private void drawBoard() {
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                JButton square = new JButton();
                squares[row][col] = square;

                square.setFont(new Font("Segoe UI Symbol", Font.PLAIN, 50));
                square.setFocusPainted(false);

                final int r = row;
                final int c = col;
                square.addActionListener(e -> handleClick(r, c));

                add(square);
            }
        }
    }

    private List<int[]> getValidMovesForPiece(int row, int col) {
        Piece[][] pieces = board.getBoard();
        Piece piece = pieces[row][col];
        if (piece == null) return new ArrayList<>();

        List<int[]> basicMoves = piece.getValidMoves(row, col, pieces);
        List<int[]> legalMoves = new ArrayList<>();

        for (int[] move : basicMoves) {
            int dr = move[0];
            int dc = move[1];

            // اگر مهره شاه است و قصد قلعه رفتن دارد، مستقیماً متد شرط قلعه را چک کن
            if (piece instanceof King && row == dr && Math.abs(dc - col) == 2) {
                // اگر شرایط قلعه برقرار نبود، اصلاً این خانه را هایلایت نکن
                if (!board.isInCheck(piece.isWhite())) { 
                    // این خط بررسی می‌کند اگر شاه کیش است کلاً قلعه هایلایت نشود
                    if (dc == 6 && (board.isSquareAttacked(row, 5, !piece.isWhite()) || board.isSquareAttacked(row, 6, !piece.isWhite()))) continue;
                    if (dc == 2 && (board.isSquareAttacked(row, 3, !piece.isWhite()) || board.isSquareAttacked(row, 2, !piece.isWhite()))) continue;
                } else {
                    continue; // اگر در کیش بود، حرکت قلعه هایلایت نشود
                }
            }

            if (!board.wouldBeInCheckAfterMove(row, col, dr, dc, piece.isWhite())) {
                legalMoves.add(move);
            }
        }
        return legalMoves;
    }

    private void handleClick(int row, int col) {
        Piece[][] pieces = board.getBoard();

        // اگر هنوز مهره‌ای انتخاب نشده
        if (selectedRow == -1) {
            Piece clicked = pieces[row][col];

            if (clicked == null) return;

            // فقط مهره‌ی نوبت خودش قابل انتخاب باشد
            if (whiteTurn && !clicked.isWhite()) return;
            if (!whiteTurn && clicked.isWhite()) return;

            selectedRow = row;
            selectedCol = col;
            currentHighlights = getValidMovesForPiece(row, col);
            applyHighlights();
            return;
        }

        Piece selectedPiece = pieces[selectedRow][selectedCol];
        Piece clickedPiece = pieces[row][col];

        // اگر وضعیت خراب شده بود
        if (selectedPiece == null) {
            clearSelection();
            return;
        }

        // اگر روی مهره هم‌رنگ خودش کلیک کرد، انتخاب عوض شود
        if (clickedPiece != null && clickedPiece.isWhite() == selectedPiece.isWhite()) {
            // فقط اگر نوبت همان رنگ باشد
            if (whiteTurn && !clickedPiece.isWhite()) return;
            if (!whiteTurn && clickedPiece.isWhite()) return;

            selectedRow = row;
            selectedCol = col;
            currentHighlights = getValidMovesForPiece(row, col);
            applyHighlights();
            return;
        }

        // اگر مقصد معتبر نیست، انتخاب پاک شود
        if (!selectedPiece.isValidMove(selectedRow, selectedCol, row, col, pieces)) {
            clearSelection();
            return;
        }

        Piece captured = pieces[row][col];

        // حرکت فقط از طریق Board انجام شود
        boolean moved = board.movePiece(selectedRow, selectedCol, row, col);
        if (!moved) {
            clearSelection();
            return;
        }

        // ثبت مهره گرفته‌شده
        if (captured != null && capturedPanel != null) {
            capturedPanel.addCapturedPiece(captured);
        }


        // برای ترفیع سرباز (Pawn Promotion)
        Piece movedPiece = board.getPiece(row, col);
            if (movedPiece instanceof Pawn) {
               // ردیف آخر برای سفید 0 و برای سیاه 7 است
                if ((movedPiece.isWhite() && row == 0) || (!movedPiece.isWhite() && row == 7)) {
                  String[] options = {"Queen", "Rook", "Knight", "Bishop"};
        
               // نمایش یک دیالوگ گرافیکی برای انتخاب مهره
                  int choice = JOptionPane.showOptionDialog(
                   this,
                   "Choose a piece for Pawn Promotion:",
                   "Pawn Promotion",
                   JOptionPane.DEFAULT_OPTION,
                   JOptionPane.PLAIN_MESSAGE,
                    null,
                    options,
                    options[0]
                );

              // اگر کاربر پنجره را بست، به صورت پیش‌فرض وزیر (Queen) انتخاب شود
                 String promoted = (choice == JOptionPane.CLOSED_OPTION) ? "Queen" : options[choice];

                 // اعمال ترفیع در برد اصلی
                 board.promotePawn(row, col, promoted, movedPiece.isWhite());
            }
        }
        
                refreshBoard();
                clearSelection();


                // تعویض نوبت
                whiteTurn = !whiteTurn;
                   if (timerPanel != null) {
                 timerPanel.setWhiteTurn(whiteTurn);


                 //  کد جدید برای تشخیص کیش، کیش و مات، و پات 
                 boolean currentTurnIsWhite = whiteTurn;
                 boolean hasMoves = board.hasAnyValidMoves(currentTurnIsWhite);
                 boolean inCheck = board.isInCheck(currentTurnIsWhite);


                if (!hasMoves) {
                    if (inCheck) {
                       // هیچ حرکتی ندارد و کیش است -> کیش و مات
                       String winner = currentTurnIsWhite ? "Black" : "White";
                       JOptionPane.showMessageDialog(this, "Checkmate! " + winner + " wins the game!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                       // هیچ حرکتی ندارد اما کیش نیست -> پات (تساوی)
                       JOptionPane.showMessageDialog(this, "Stalemate! The game is a draw.", "Game Over", JOptionPane.INFORMATION_MESSAGE);
                }
                // اینجا می‌توانید در صورت نیاز دکمه‌ها را غیرفعال کنید تا بازی تمام شود
                } else if (inCheck) {
                   // بازیکن حرکت دارد اما در کیش است -> فقط هشدار کیش
                   String targetKing = currentTurnIsWhite ? "White" : "Black";
                   JOptionPane.showMessageDialog(this, targetKing + " King is in CHECK! ", "Warning", JOptionPane.WARNING_MESSAGE);
                }

                }
            }
    

    private void refreshBoard() {
        Piece[][] pieces = board.getBoard();

        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                Piece p = pieces[row][col];
                squares[row][col].setText(p != null ? p.getSymbol() : "");
            }
        }
    }

    private void resetColors() {
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                if ((row + col) % 2 == 0) {
                    squares[row][col].setBackground(LIGHT_SQUARE);
                } else {
                    squares[row][col].setBackground(DARK_SQUARE);
                }
            }
        }
    }

    private void applyHighlights() {
        resetColors();

        for (int[] move : currentHighlights) {
            int r = move[0];
            int c = move[1];
            squares[r][c].setBackground(HIGHLIGHT_COLOR);
        }

        if (selectedRow != -1 && selectedCol != -1) {
            squares[selectedRow][selectedCol].setBackground(SELECTED_COLOR);
        }
    }

    private void clearSelection() {
        selectedRow = -1;
        selectedCol = -1;
        currentHighlights.clear();
        resetColors();
    }
}
