import pieces.*;

public class Board {

    private Piece[][] board;

    public Board() {
        board = new Piece[8][8];
        setupBoard();
    }

    public Piece[][] getBoard() {
        return board;
    }

    public Piece getPiece(int row, int col) {
        if (!isInsideBoard(row, col)) return null;
        return board[row][col];
    }

    public boolean movePiece(int sr, int sc, int dr, int dc) {
        if (!isInsideBoard(sr, sc) || !isInsideBoard(dr, dc)) return false;

        Piece piece = board[sr][sc];

         // مبدا خالی است
        if (piece == null) return false;

         // ۱. بررسی معتبر بودن حرکت پایه‌ای خود مهره
        if (!piece.isValidMove(sr, sc, dr, dc, board)) return false;

        if (piece instanceof King && sr ==dr && Math.abs(dc - sc) == 2){
            if (!checkCastlingConditions(sr, sc, dr, dc, piece.isWhite())){
                return false;
            }
        }

        if (wouldBeInCheckAfterMove(sr, sc, dr, dc, piece.isWhite())){
            return false;
        }

        if ( piece instanceof King && sr == dr && sc == 4 && Math.abs(dc - sc) == 2){
            if (dc == 6) { // قلعه کوچک
               board[sr][5] = board[sr][7];
               board[sr][7] = null;
               if (board[sr][5] instanceof Rook) ((Rook) board[sr][5]).setMoved(true);
            } else if (dc == 2) { // قلعه بزرگ
               board[sr][3] = board[sr][0];
               board[sr][0] = null;
               if (board[sr][3] instanceof Rook) ((Rook) board[sr][3]).setMoved(true);
            }
        }
        

        // انجام نهایی حرکت واقعی شاه یا هر مهره دیگر
         board[dr][dc] = piece;
         board[sr][sc] = null;

        // تغییر وضعیت حرکت مهره‌ها برای دفعات بعدی
         if (piece instanceof King) {
           ((King) piece).setMoved(true);
        } else if (piece instanceof Rook) {
           ((Rook) piece).setMoved(true);
        }

         return true;
    }

    private boolean isInsideBoard(int row, int col) {
        return row >= 0 && row < 8 && col >= 0 && col < 8;
    }

    private void setupBoard() {

        // Black pieces
        board[0][0] = new Rook(false);
        board[0][1] = new Knight(false);
        board[0][2] = new Bishop(false);
        board[0][3] = new Queen(false);
        board[0][4] = new King(false);
        board[0][5] = new Bishop(false);
        board[0][6] = new Knight(false);
        board[0][7] = new Rook(false);

        for (int i = 0; i < 8; i++) {
            board[1][i] = new Pawn(false);
        }

        // White pieces
        board[7][0] = new Rook(true);
        board[7][1] = new Knight(true);
        board[7][2] = new Bishop(true);
        board[7][3] = new Queen(true);
        board[7][4] = new King(true);
        board[7][5] = new Bishop(true);
        board[7][6] = new Knight(true);
        board[7][7] = new Rook(true);

        for (int i = 0; i < 8; i++) {
            board[6][i] = new Pawn(true);
        }
    }

    public void promotePawn(int row, int col, String choice, boolean isWhite) {
    switch (choice) {
        case "Queen" -> board[row][col] = new Queen(isWhite);
        case "Rook" -> board[row][col] = new Rook(isWhite);
        case "Knight" -> board[row][col] = new Knight(isWhite);
        case "Bishop" -> board[row][col] = new Bishop(isWhite);
        }
    }

      // ۱. بررسی اینکه آیا یک خانه توسط رنگ مقابل تهدید می‌شود یا خیر
    public boolean isSquareAttacked(int row, int col, boolean byWhite) {
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                Piece p = board[r][c];
                if (p != null && p.isWhite() == byWhite) {
                   if (p.isValidMove(r, c, row, col, board)) {
                      return true;
                    }
                }
            }
        }
         return false;
    }

      // ۲. پیدا کردن موقعیت فعلی شاه روی صفحه
    private int[] findKing(boolean isWhite) {
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                Piece p = board[r][c];
                if (p instanceof King && p.isWhite() == isWhite) {
                   return new int[]{r, c};
                }
            }
        }
         return null; // نباید رخ دهد مگر اینکه شاه حذف شده باشد
    }

      // ۳. بررسی اینکه آیا شاهِ رنگِ مورد نظر در کیش است یا خیر
    public boolean isInCheck(boolean isWhite) {
        int[] kingPos = findKing(isWhite);
        if (kingPos == null) return false;
           // آیا خانه‌ای که شاه در آن قرار دارد توسط مهره‌های رنگ مخالف تهدید می‌شود؟
        return isSquareAttacked(kingPos[0], kingPos[1], !isWhite);
    }

      // ۴. شبیه‌سازی حرکت برای بررسی اینکه آیا این حرکت باعث کیش شدن شاه خودی می‌شود یا نه
    public boolean wouldBeInCheckAfterMove(int sr, int sc, int dr, int dc, boolean isWhite) {
         Piece originalSrc = board[sr][sc];
         Piece originalDst = board[dr][dc];

        // انجام موقت حرکت در آرایه
         board[dr][dc] = originalSrc;
         board[sr][sc] = null;

        // بررسی وضعیت کیش پس از حرکت فرضی
          boolean inCheck = isInCheck(isWhite);

        // بازگرداندن مهره‌ها به حالت اولیه (Undo)
         board[sr][sc] = originalSrc;
         board[dr][dc] = originalDst;

        return inCheck;
    }

      // ۵. بررسی اینکه آیا بازیکن در نوبت خود هیچ حرکت قانونی دارد یا خیر
    public boolean hasAnyValidMoves(boolean isWhite) {
        for (int sr = 0; sr < 8; sr++) {
            for (int sc = 0; sc < 8; sc++) {
                Piece p = board[sr][sc];
                if (p != null && p.isWhite() == isWhite) {
                    // بررسی تمام خانه‌های صفحه به عنوان مقصد احتمالی
                    for (int dr = 0; dr < 8; dr++) {
                        for (int dc = 0; dc < 8; dc++) {
                            // الف) آیا مهره از نظر ساختاری می‌تواند این حرکت را انجام دهد؟
                            if (p.isValidMove(sr, sc, dr, dc, board)) {
                                // ب) آیا این حرکت باعث به خطر افتادن شاه خودی می‌شود؟
                                if (!wouldBeInCheckAfterMove(sr, sc, dr, dc, isWhite)) {
                                    return true; // حداقل یک حرکت قانونی وجود دارد
                                }
                            }
                        }
                    }
                }
            }
        }
         return false; // هیچ حرکت قانونی وجود ندارد
    }

    // بررسی دقیق شرایط قلعه رفتن (مسیر خالی و عدم کیش در طول مسیر)
public boolean checkCastlingConditions(int sr, int sc, int dr, int dc, boolean isWhite) {
    boolean opponentColor = !isWhite;

    
    // ۱. شاه در حال حاضر (در خانه مبدا) نباید کیش باشد
    if (isInCheck(isWhite)) return false;

    if (dc == 6) { // قلعه کوچک (سمت راست)
        // الف) مسیر باید کاملاً خالی باشد (ستون‌های 5 و 6)
        if (board[sr][5] != null || board[sr][6] != null) return false;
        
        // ب) شاه نباید از خانه زیر ضربه عبور کند (ستون 5) یا در خانه زیر ضربه قرار گیرد (ستون 6)
        if (isSquareAttacked(sr, 5, opponentColor) || isSquareAttacked(sr, 6, opponentColor)) return false;
        
    } else if (dc == 2) { // قلعه بزرگ (سمت چپ)
        // الف) مسیر باید کاملاً خالی باشد (ستون‌های 1، 2 و 3)
        if (board[sr][1] != null || board[sr][2] != null || board[sr][3] != null) return false;
        
        // ب) شاه نباید از خانه زیر ضربه عبور کند (ستون 3) یا در خانه زیر ضربه قرار گیرد (ستون 2)
        // (نکته: طبق قوانین شطرنج، ستون 1 زیر ضربه باشد اشکالی ندارد چون شاه از آن عبور نمی‌کند)
        if (isSquareAttacked(sr, 3, opponentColor) || isSquareAttacked(sr, 2, opponentColor)) return false;
    }
    
    return true;
}
}
